# 構成パターン別サンプルプロジェクト

同じ機能（BOM閲覧：構成マスタ＋品目マスタから画面用データを組み立てる）を
5つの構成で実装したサンプルです。ビルドは通しておらず、構成の比較用です。

| ディレクトリ | 構成 |
|---|---|
| `pattern1-A-usecase-crossref/` | ユースケース単位 × 外から呼ぶ（フィーチャー間依存） |
| `pattern1-B-usecase-duplicate/` | ユースケース単位 × それぞれで持つ（ロジック重複） |
| `pattern1-C-usecase-join/` | ユースケース単位 × RepositoryでJOIN集約 |
| `pattern2-vertical-slice-entity/` | Vertical Slice × エンティティ単位 |
| `pattern3-layered-entity/` | レイヤード × エンティティ単位（採用案） |

## 題材

- 品目マスタ（PRODUCT）… 品番、品名、型式、廃番フラグ
- 構成マスタ（BOM）… 親品番、構成品番、員数
- BOM閲覧画面 … 構成一覧に品名を並べて表示する（＝2つのマスタが必要）
- 業務ルール … 廃番品は表示しない

この「2つのマスタをまたぐ」という一点だけで、
構成ごとの向き不向きがはっきり出ます。

## 読む順番

1. 各プロジェクトの `README.md` で狙いと結果を確認
2. `BomService.cs` / `BomQueryService.cs` を比較（差が一番大きい）
3. `pattern3` の `Program.cs` と `ShadowProductRepository.cs` で
   移行時の切り替えがどう効くかを確認

## 注意

.csproj は含めていません（構成の比較が目的のため）。
実際に動かす場合は各プロジェクトルートで `dotnet new webapi` してから
`src/` を差し込んでください。
