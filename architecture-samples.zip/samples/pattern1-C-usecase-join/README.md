# パターン1-C：ユースケース単位 × Repositoryで集約（JOIN）

BomRepository の中で構成マスタと品目マスタをJOINし、
画面に必要な形を1クエリで返す構成。今のClassic ASPに近い。

## 見どころ

- `Features/BOM閲覧/Repositories/BomRepository.cs`
  → SQL内で PRODUCT へ直接JOIN。廃番除外の条件もSQLに入っている。
- `Features/BOM閲覧/Services/BomService.cs`
  → Repositoryが完成形を返すため、ほぼ素通し。

## 結果

- 実装量は最小。クエリ1本で速い。機能内に閉じている
- 移行途中でBOM(AS400)とPRODUCT(ERP)が分かれるとJOINが書けない
- 品目マスタを参照する全機能のSQLに業務ルールが散る
- 新旧の突き合わせ検証を仕込む場所がない
