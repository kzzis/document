using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

public class BomRepository : IBomRepository
{
    private const string Sql = @"
        SELECT  b.COMPONENT_PRODUCT_ID,
                p.PRODUCT_NAME,
                b.QUANTITY
        FROM    BOM b
        INNER JOIN PRODUCT p                      -- ★ 品目マスタへ直接JOIN
                ON p.PRODUCT_ID = b.COMPONENT_PRODUCT_ID
        WHERE   b.PARENT_PRODUCT_ID = @parentProductId
          AND   p.IS_DISCONTINUED = 0             -- ★ 業務ルールがSQLの中に埋まる
        ORDER BY b.COMPONENT_PRODUCT_ID";

    public Task<BomView> GetBomViewAsync(string parentProductId)
    {
        // メリット：クエリ1本で完結する。速い。機能の中に閉じている。
        //
        // デメリット(1) 移行途中、BOMがAS400・PRODUCTがERP側になると
        //               このJOINは物理的に書けなくなる。
        // デメリット(2) 品目マスタを参照している全機能のSQLに同じ条件が散る。
        //               「廃番品は除外」のルールが変わると全部探して直す。
        // デメリット(3) 新旧の突き合わせ検証を仕込む場所がない。
        throw new NotImplementedException();
    }
}
