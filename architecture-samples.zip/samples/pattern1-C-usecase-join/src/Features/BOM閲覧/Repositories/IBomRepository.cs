using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

/// <summary>
/// 画面に必要な形（構成＋品目名）を、そのまま1回で返す。
/// Repositoryのインターフェースが「画面の都合」に寄っているのが特徴。
/// </summary>
public interface IBomRepository
{
    Task<BomView> GetBomViewAsync(string parentProductId);
}
