using Sample.Features.Bom.Models;
using Sample.Features.Bom.Repositories;

namespace Sample.Features.Bom.Services;

/// <summary>
/// Repositoryが完成形を返すため、Serviceはほぼ素通し。
/// 実装量は最小だが、その分ロジックがSQLに寄っている。
/// </summary>
public class BomService : IBomService
{
    private readonly IBomRepository _bomRepository;

    public BomService(IBomRepository bomRepository) => _bomRepository = bomRepository;

    public Task<BomView> GetAsync(string parentProductId)
        => _bomRepository.GetBomViewAsync(parentProductId);
}
