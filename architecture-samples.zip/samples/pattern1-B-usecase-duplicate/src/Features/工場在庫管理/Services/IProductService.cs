using Sample.Features.FactoryInventory.Models;

namespace Sample.Features.FactoryInventory.Services;

/// <summary>このフィーチャー内部でのみ使う（外に公開しない）。</summary>
public interface IProductService
{
    Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds);
}
