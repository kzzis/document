using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

public class BomProductRepository : IBomProductRepository
{
    public Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
    {
        // SELECT * FROM PRODUCT WHERE PRODUCT_ID IN (...)
        // ↑ 工場在庫管理側のProductRepositoryと同じSQL。
        //   品目マスタに項目が増えたら、両方直す必要がある。
        throw new NotImplementedException();
    }
}
