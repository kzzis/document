using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

/// <summary>
/// ★★ 重複ポイント(1) ★★
/// 工場在庫管理/Repositories/IProductRepository.cs と実質同じもの。
/// 同じ品目マスタテーブルに、別経路でアクセスしている。
/// </summary>
public interface IBomProductRepository
{
    Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds);
}
