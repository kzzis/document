using Sample.Features.Bom.Models;
using Sample.Features.Bom.Repositories;

namespace Sample.Features.Bom.Services;

/// <summary>
/// 他フィーチャーへの参照は一切ない（＝完全に独立している）。
/// その代償として、品目マスタ関連のコードを丸ごと自前で抱えている。
/// </summary>
public class BomService : IBomService
{
    private readonly IBomRepository _bomRepository;
    private readonly IBomProductService _bomProductService;

    public BomService(IBomRepository bomRepository, IBomProductService bomProductService)
    {
        _bomRepository = bomRepository;
        _bomProductService = bomProductService;
    }

    public async Task<BomView> GetAsync(string parentProductId)
    {
        var components = await _bomRepository.GetComponentsAsync(parentProductId);
        var products = await _bomProductService.GetActiveByIdsAsync(
            components.Select(c => c.ComponentProductId));

        var nameById = products.ToDictionary(p => p.ProductId, p => p.ProductName);

        return new BomView
        {
            ParentProductId = parentProductId,
            Items = components.Select(c => new BomViewItem
            {
                ComponentProductId = c.ComponentProductId,
                ProductName = nameById.GetValueOrDefault(c.ComponentProductId, ""),
                Quantity = c.Quantity
            }).ToList()
        };
    }
}
