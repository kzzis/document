using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Services;

/// <summary>
/// ★★ 重複ポイント(2) ★★
/// 工場在庫管理/Services/IProductService.cs と実質同じもの。
/// </summary>
public interface IBomProductService
{
    Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds);
}
