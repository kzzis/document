using Sample.Features.Bom.Models;
using Sample.Features.Bom.Repositories;

namespace Sample.Features.Bom.Services;

public class BomProductService : IBomProductService
{
    private readonly IBomProductRepository _repository;

    public BomProductService(IBomProductRepository repository)
        => _repository = repository;

    public async Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds)
    {
        var products = await _repository.GetByIdsAsync(productIds);

        // ★ 業務ルール「廃番品は除外する」が2箇所に存在する。
        //   工場在庫管理側だけルールが変わると、画面によって結果が食い違う。
        return products.Where(p => !p.IsDiscontinued).ToList();
    }
}
