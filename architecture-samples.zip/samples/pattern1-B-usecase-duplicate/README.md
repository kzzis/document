# パターン1-B：ユースケース単位 × それぞれで持つ

フィーチャー間の参照をなくすため、BOM閲覧が品目マスタ用の
Repository / Service を自前で持つ構成。

## 見どころ

- `Features/BOM閲覧/Repositories/BomProductRepository.cs`
- `Features/BOM閲覧/Services/BomProductService.cs`
  → 工場在庫管理側の ProductRepository / ProductService と実質同じ。
     「廃番品は除外する」の業務ルールが2箇所に存在する。

## 結果

- 各フィーチャーは完全に独立（フォルダごと削除できる）
- 品目マスタの仕様変更のたびに2セット直す必要がある
- 片方だけ直すと画面によって結果が食い違う
