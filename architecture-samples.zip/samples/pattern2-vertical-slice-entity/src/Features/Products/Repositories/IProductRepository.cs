using Sample.Features.Products.Models;

namespace Sample.Features.Products.Repositories;

/// <summary>
/// フィーチャー内部専用。他フィーチャーからの直接参照はNG。
/// </summary>
public interface IProductRepository
{
    Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds);
}
