using Sample.Features.Products.Models;

namespace Sample.Features.Products.Repositories;

public class ProductRepository : IProductRepository
{
    public Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
    {
        // SELECT * FROM PRODUCT WHERE PRODUCT_ID IN (...)
        throw new NotImplementedException();
    }
}
