using Sample.Features.Products.Models;

namespace Sample.Features.Products.Services;

/// <summary>他フィーチャーへの唯一の公開窓口。</summary>
public interface IProductService
{
    Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds);
}
