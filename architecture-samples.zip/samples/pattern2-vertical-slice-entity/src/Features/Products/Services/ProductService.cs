using Sample.Features.Products.Models;
using Sample.Features.Products.Repositories;

namespace Sample.Features.Products.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
        => _productRepository = productRepository;

    public async Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds)
    {
        var products = await _productRepository.GetByIdsAsync(productIds);
        return products.Where(p => !p.IsDiscontinued).ToList();  // 業務ルールは1箇所
    }
}
