namespace Sample.Features.Products.Models;

/// <summary>品目マスタ</summary>
public class Product
{
    public string ProductId { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string ModelCode { get; set; } = "";
    /// <summary>廃番フラグ（表示時は除外するのが業務ルール）</summary>
    public bool IsDiscontinued { get; set; }
}
