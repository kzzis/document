using Sample.Features.Bom.Models;
using Sample.Features.Bom.Repositories;
using Sample.Features.Products.Services;   // ← 他フィーチャーのServiceを参照

namespace Sample.Features.Bom.Services;

/// <summary>
/// ★ 複合サービスの置き場所問題 ★
///
/// 構成マスタ（Bom）と品目マスタ（Products）の2つを使う処理。
/// どこに置いても収まりが悪い：
///
///   Bom/ に置く      → Bom側がProductsに依存し「独立した箱」が崩れる（今のコード）
///   Products/ に置く → BOMの都合で品目マスタ側にコードが増えていく
///   専用フィーチャー → 実質パターン1（ユースケース単位）に逆戻り
///
/// さらにルール上、他フィーチャーのRepositoryは直接呼べないため
/// IProductService を経由することになり、経路が1段深くなる：
///
///   BomService → IProductService → ProductRepository
///                ~~~~~~~~~~~~~~~ 単に品目名が欲しいだけなのに1ホップ増える
/// </summary>
public class BomService : IBomService
{
    private readonly IBomRepository _bomRepository;
    private readonly IProductService _productService;

    public BomService(IBomRepository bomRepository, IProductService productService)
    {
        _bomRepository = bomRepository;
        _productService = productService;
    }

    public async Task<BomView> GetAsync(string parentProductId)
    {
        var components = await _bomRepository.GetComponentsAsync(parentProductId);
        var products = await _productService.GetActiveByIdsAsync(
            components.Select(c => c.ComponentProductId));

        var nameById = products.ToDictionary(p => p.ProductId, p => p.ProductName);

        return new BomView
        {
            ParentProductId = parentProductId,
            Items = components.Select(c => new BomViewItem
            {
                ComponentProductId = c.ComponentProductId,
                ProductName = nameById.GetValueOrDefault(c.ComponentProductId, ""),
                Quantity = c.Quantity
            }).ToList()
        };
    }
}
