using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

public class BomRepository : IBomRepository
{
    public Task<IReadOnlyList<BomComponent>> GetComponentsAsync(string parentProductId)
    {
        // SELECT * FROM BOM WHERE PARENT_PRODUCT_ID = @parentProductId
        // 品目マスタへのJOINはしない（持ち主が違うため）
        throw new NotImplementedException();
    }
}
