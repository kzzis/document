namespace Sample.Features.Bom.Models;

public class BomView
{
    public string ParentProductId { get; set; } = "";
    public List<BomViewItem> Items { get; set; } = new();
}

public class BomViewItem
{
    public string ComponentProductId { get; set; } = "";
    public string ProductName { get; set; } = "";   // ← 品目マスタから引く
    public decimal Quantity { get; set; }
}
