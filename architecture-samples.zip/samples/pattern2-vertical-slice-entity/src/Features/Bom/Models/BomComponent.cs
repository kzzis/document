namespace Sample.Features.Bom.Models;

/// <summary>構成マスタ（このフィーチャーが持ち主）</summary>
public class BomComponent
{
    public string ParentProductId { get; set; } = "";
    public string ComponentProductId { get; set; } = "";
    public decimal Quantity { get; set; }
}
