# パターン2：Vertical Slice × エンティティ単位

フィーチャーをエンティティ（Products / Bom）で切り、
それぞれがController〜Repositoryを一式持つ構成。

## 見どころ

- `Features/Bom/Services/BomService.cs`
  → 複合サービスの置き場所問題。コメントに3案の比較を書いてある。
     ルール上、他フィーチャーのRepositoryは直接呼べないため
     IProductService を経由し、経路が1段深くなる。

## 結果

- 業務ルールは1箇所（重複なし）
- 1フィーチャー＝1フォルダで全体像を把握しやすい
- 依存の向き（Controller→Service→Repository）が構造に現れない
- 2つのマスタをまたぐ処理の置き場所が決まらない
