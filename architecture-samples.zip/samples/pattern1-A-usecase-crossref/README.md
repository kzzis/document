# パターン1-A：ユースケース単位 × 外から呼ぶ

フィーチャーを「工場在庫管理」「BOM閲覧」という画面単位で切り、
品目マスタは工場在庫管理が持ち、BOM閲覧はそれを借りる構成。

## 見どころ

- `Features/BOM閲覧/Services/BomService.cs`
  → `Sample.Features.FactoryInventory.Services` を using している。
     ここがフィーチャー間依存。

## 結果

- ロジックは1箇所（整合性は保たれる）
- ただし「工場在庫管理」を消すとBOM閲覧も動かない
- 品目マスタの持ち主がフォルダ名から読み取れない
