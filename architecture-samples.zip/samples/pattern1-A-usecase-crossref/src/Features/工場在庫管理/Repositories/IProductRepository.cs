using Sample.Features.FactoryInventory.Models;

namespace Sample.Features.FactoryInventory.Repositories;

public interface IProductRepository
{
    Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds);
}
