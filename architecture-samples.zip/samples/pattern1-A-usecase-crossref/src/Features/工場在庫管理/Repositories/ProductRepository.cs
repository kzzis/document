using Sample.Features.FactoryInventory.Models;

namespace Sample.Features.FactoryInventory.Repositories;

/// <summary>品目マスタへのアクセス。持ち主はこのフィーチャー。</summary>
public class ProductRepository : IProductRepository
{
    public Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
    {
        // SELECT * FROM PRODUCT WHERE PRODUCT_ID IN (...)
        throw new NotImplementedException();
    }
}
