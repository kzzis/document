using Microsoft.AspNetCore.Mvc;
using Sample.Features.FactoryInventory.Services;

namespace Sample.Features.FactoryInventory.Controllers;

[ApiController]
[Route("api/factory-inventory")]
public class InventoryController : ControllerBase
{
    private readonly IProductService _productService;

    public InventoryController(IProductService productService)
        => _productService = productService;

    [HttpGet("list")]
    public async Task<IActionResult> GetList([FromQuery] string[] productIds)
        => Ok(await _productService.GetActiveByIdsAsync(productIds));
}
