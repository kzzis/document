using Sample.Features.FactoryInventory.Models;
using Sample.Features.FactoryInventory.Repositories;

namespace Sample.Features.FactoryInventory.Services;

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
        => _productRepository = productRepository;

    public async Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds)
    {
        var products = await _productRepository.GetByIdsAsync(productIds);
        // 業務ルール：廃番品は除外する（★このロジックの本体はここ1箇所）
        return products.Where(p => !p.IsDiscontinued).ToList();
    }
}
