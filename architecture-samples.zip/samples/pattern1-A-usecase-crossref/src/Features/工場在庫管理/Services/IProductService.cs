using Sample.Features.FactoryInventory.Models;

namespace Sample.Features.FactoryInventory.Services;

/// <summary>
/// ★ 本来このフィーチャーの内部都合だけで済ませたいが、
///    BOM閲覧から使われるため公開せざるを得ない。
/// </summary>
public interface IProductService
{
    Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds);
}
