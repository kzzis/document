using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

/// <summary>構成マスタのみを担当する。品目マスタには触らない。</summary>
public class BomRepository : IBomRepository
{
    public Task<IReadOnlyList<BomComponent>> GetComponentsAsync(string parentProductId)
    {
        // SELECT * FROM BOM WHERE PARENT_PRODUCT_ID = @parentProductId
        throw new NotImplementedException();
    }
}
