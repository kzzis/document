using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Repositories;

public interface IBomRepository
{
    Task<IReadOnlyList<BomComponent>> GetComponentsAsync(string parentProductId);
}
