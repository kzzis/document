using Microsoft.AspNetCore.Mvc;
using Sample.Features.Bom.Services;

namespace Sample.Features.Bom.Controllers;

[ApiController]
[Route("api/bom")]
public class BomController : ControllerBase
{
    private readonly IBomService _bomService;

    public BomController(IBomService bomService) => _bomService = bomService;

    [HttpGet("{productId}")]
    public async Task<IActionResult> Get(string productId)
        => Ok(await _bomService.GetAsync(productId));
}
