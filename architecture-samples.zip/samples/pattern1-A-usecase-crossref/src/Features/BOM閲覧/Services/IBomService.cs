using Sample.Features.Bom.Models;

namespace Sample.Features.Bom.Services;

public interface IBomService
{
    Task<BomView> GetAsync(string parentProductId);
}
