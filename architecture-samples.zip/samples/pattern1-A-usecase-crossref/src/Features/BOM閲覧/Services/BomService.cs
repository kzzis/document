using Sample.Features.Bom.Repositories;
using Sample.Features.Bom.Models;
using Sample.Features.FactoryInventory.Models;
using Sample.Features.FactoryInventory.Services;   // ★ フィーチャーをまたいだ参照

namespace Sample.Features.Bom.Services;

public class BomService : IBomService
{
    private readonly IBomRepository _bomRepository;

    // ★★ ここが問題点 ★★
    // 「工場在庫管理」フィーチャーのServiceに依存している。
    // 独立した箱にしたはずが、フィーチャー間依存が発生している。
    // 工場在庫管理フィーチャーを削除すると、BOM閲覧も動かなくなる。
    private readonly IProductService _productService;

    public BomService(IBomRepository bomRepository, IProductService productService)
    {
        _bomRepository = bomRepository;
        _productService = productService;
    }

    public async Task<BomView> GetAsync(string parentProductId)
    {
        var components = await _bomRepository.GetComponentsAsync(parentProductId);

        // 経路が1段深い：BomService → IProductService → ProductRepository
        var products = await _productService.GetActiveByIdsAsync(
            components.Select(c => c.ComponentProductId));

        var nameById = products.ToDictionary(p => p.ProductId, p => p.ProductName);

        return new BomView
        {
            ParentProductId = parentProductId,
            Items = components.Select(c => new BomViewItem
            {
                ComponentProductId = c.ComponentProductId,
                ProductName = nameById.GetValueOrDefault(c.ComponentProductId, ""),
                Quantity = c.Quantity
            }).ToList()
        };
    }
}
