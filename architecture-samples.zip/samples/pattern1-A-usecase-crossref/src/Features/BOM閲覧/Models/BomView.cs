namespace Sample.Features.Bom.Models;

/// <summary>BOM閲覧画面に返す形</summary>
public class BomView
{
    public string ParentProductId { get; set; } = "";
    public List<BomViewItem> Items { get; set; } = new();
}

public class BomViewItem
{
    public string ComponentProductId { get; set; } = "";
    /// <summary>品目マスタから引く（構成マスタには入っていない）</summary>
    public string ProductName { get; set; } = "";
    public decimal Quantity { get; set; }
}
