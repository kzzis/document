# パターン3：レイヤード × エンティティ単位（採用案）

層で分け、その中をエンティティのサブフォルダで分ける構成。

## 見どころ

- `Services/Bom/BomQueryService.cs`
  → 複合サービス。2つのRepositoryを直接注入するだけ。置き場所に迷わない。
- `Repositories/Products/ShadowProductRepository.cs`
  → 新旧を突き合わせるDecorator。品目マスタへのアクセスが1箇所に
     集約されているため、ここに仕込むだけで全機能が検証対象になる。
- `Program.cs`
  → 移行の切り替えがDI登録1箇所で完結することを示す。
     As400ProductRepository → Shadow → ProductRepository と差し替えるだけ。

## 結果

- 依存の向きがトップレベルの構造に現れる
- Repository層の横断作業（移行）が Repositories/ を開くだけで済む
- 複合サービスの置き場所が一意に決まる
- 1つのエンティティに関わるコードは4フォルダに分散する
