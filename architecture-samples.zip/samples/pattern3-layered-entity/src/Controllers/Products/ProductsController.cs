using Microsoft.AspNetCore.Mvc;
using Sample.Services.Products;

namespace Sample.Controllers.Products;

[ApiController]
[Route("api/products")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;

    public ProductsController(IProductService productService)
        => _productService = productService;

    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string[] ids)
        => Ok(await _productService.GetActiveByIdsAsync(ids));
}
