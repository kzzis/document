using Microsoft.AspNetCore.Mvc;
using Sample.Services.Bom;

namespace Sample.Controllers.Bom;

[ApiController]
[Route("api/bom")]
public class BomController : ControllerBase
{
    private readonly IBomQueryService _bomQueryService;

    public BomController(IBomQueryService bomQueryService)
        => _bomQueryService = bomQueryService;

    [HttpGet("{productId}")]
    public async Task<IActionResult> Get(string productId)
        => Ok(await _bomQueryService.GetAsync(productId));
}
