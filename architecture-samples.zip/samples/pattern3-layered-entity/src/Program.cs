using Sample.Repositories.Bom;
using Sample.Repositories.Products;
using Sample.Services.Bom;
using Sample.Services.Products;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();

// --- Repositories ---
builder.Services.AddScoped<IBomRepository, BomRepository>();

// ★ 移行の切り替えはここ1箇所で完結する ★
//   移行前  : As400ProductRepository
//   検証中  : ShadowProductRepository（新旧を突き合わせ）
//   移行後  : ProductRepository
builder.Services.AddScoped<IProductRepository>(sp =>
    new ShadowProductRepository(
        legacy: new As400ProductRepository(),
        next: new ProductRepository()));

// --- Services ---
builder.Services.AddScoped<IProductService, ProductService>();
builder.Services.AddScoped<IBomQueryService, BomQueryService>();

var app = builder.Build();
app.MapControllers();
app.Run();
