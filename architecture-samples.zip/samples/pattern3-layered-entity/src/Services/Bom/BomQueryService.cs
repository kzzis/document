using Sample.Models.Bom;
using Sample.Repositories.Bom;
using Sample.Repositories.Products;

namespace Sample.Services.Bom;

/// <summary>
/// ★ 複合サービス ★
///
/// 構成マスタと品目マスタの2つを使うが、置き場所に迷わない。
/// BOMを主体とする処理なので Services/Bom/ に置く。それだけ。
///
/// 必要なRepositoryを直接注入できるため、経路も浅い：
///   BomQueryService → IProductRepository
///   （パターン2のように 別フィーチャーのService を経由しない）
///
/// 取得は IProductRepository を通るので、
/// AS400→ERPの切り替えも Shadow による突き合わせ検証も
/// DI登録の差し替え1箇所で吸収できる。
/// </summary>
public class BomQueryService : IBomQueryService
{
    private readonly IBomRepository _bomRepository;
    private readonly IProductRepository _productRepository;

    public BomQueryService(
        IBomRepository bomRepository,
        IProductRepository productRepository)
    {
        _bomRepository = bomRepository;
        _productRepository = productRepository;
    }

    public async Task<BomView> GetAsync(string parentProductId)
    {
        var components = await _bomRepository.GetComponentsAsync(parentProductId);
        var products = await _productRepository.GetByIdsAsync(
            components.Select(c => c.ComponentProductId));

        var nameById = products
            .Where(p => !p.IsDiscontinued)
            .ToDictionary(p => p.ProductId, p => p.ProductName);

        return new BomView
        {
            ParentProductId = parentProductId,
            Items = components.Select(c => new BomViewItem
            {
                ComponentProductId = c.ComponentProductId,
                ProductName = nameById.GetValueOrDefault(c.ComponentProductId, ""),
                Quantity = c.Quantity
            }).ToList()
        };
    }
}
