using Sample.Models.Bom;

namespace Sample.Services.Bom;

public interface IBomQueryService
{
    Task<BomView> GetAsync(string parentProductId);
}
