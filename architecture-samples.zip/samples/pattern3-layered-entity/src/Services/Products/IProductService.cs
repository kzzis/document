using Sample.Models.Products;

namespace Sample.Services.Products;

public interface IProductService
{
    Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds);
}
