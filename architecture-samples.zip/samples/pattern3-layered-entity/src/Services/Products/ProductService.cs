using Sample.Models.Products;
using Sample.Repositories.Products;

namespace Sample.Services.Products;

public class ProductService : IProductService
{
    private readonly IProductRepository _productRepository;

    public ProductService(IProductRepository productRepository)
        => _productRepository = productRepository;

    public async Task<IReadOnlyList<Product>> GetActiveByIdsAsync(IEnumerable<string> productIds)
    {
        var products = await _productRepository.GetByIdsAsync(productIds);
        return products.Where(p => !p.IsDiscontinued).ToList();
    }
}
