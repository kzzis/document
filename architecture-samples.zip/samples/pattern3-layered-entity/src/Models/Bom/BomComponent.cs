namespace Sample.Models.Bom;

/// <summary>構成マスタ</summary>
public class BomComponent
{
    public string ParentProductId { get; set; } = "";
    public string ComponentProductId { get; set; } = "";
    public decimal Quantity { get; set; }
}
