namespace Sample.Models.Bom;

public class BomView
{
    public string ParentProductId { get; set; } = "";
    public List<BomViewItem> Items { get; set; } = new();
}

public class BomViewItem
{
    public string ComponentProductId { get; set; } = "";
    public string ProductName { get; set; } = "";
    public decimal Quantity { get; set; }
}
