namespace Sample.Models.Products;

/// <summary>品目マスタ</summary>
public class Product
{
    public string ProductId { get; set; } = "";
    public string ProductName { get; set; } = "";
    public string ModelCode { get; set; } = "";
    public bool IsDiscontinued { get; set; }
}
