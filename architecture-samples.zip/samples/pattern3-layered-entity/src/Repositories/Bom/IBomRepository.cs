using Sample.Models.Bom;

namespace Sample.Repositories.Bom;

public interface IBomRepository
{
    Task<IReadOnlyList<BomComponent>> GetComponentsAsync(string parentProductId);
}
