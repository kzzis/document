using Sample.Models.Bom;

namespace Sample.Repositories.Bom;

public class BomRepository : IBomRepository
{
    public Task<IReadOnlyList<BomComponent>> GetComponentsAsync(string parentProductId)
    {
        // SELECT * FROM BOM WHERE PARENT_PRODUCT_ID = @parentProductId
        // 品目マスタへのJOINはしない → データソースが分かれても影響を受けない
        throw new NotImplementedException();
    }
}
