using Sample.Models.Products;

namespace Sample.Repositories.Products;

public interface IProductRepository
{
    Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds);
}
