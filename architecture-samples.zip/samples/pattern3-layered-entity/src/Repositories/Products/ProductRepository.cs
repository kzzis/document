using Sample.Models.Products;

namespace Sample.Repositories.Products;

/// <summary>ERP（PostgreSQL）側の実装</summary>
public class ProductRepository : IProductRepository
{
    public Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
        => throw new NotImplementedException();
}
