using Sample.Models.Products;

namespace Sample.Repositories.Products;

/// <summary>
/// ★ 移行の要 ★
/// 新旧の両方から取得して結果を突き合わせる Decorator。
/// 品目マスタへのアクセスがこの1箇所に集約されているため、
/// ここに仕込むだけで全機能の読み取りが検証対象になる。
/// </summary>
public class ShadowProductRepository : IProductRepository
{
    private readonly IProductRepository _legacy;   // AS400
    private readonly IProductRepository _next;     // ERP

    public ShadowProductRepository(IProductRepository legacy, IProductRepository next)
    {
        _legacy = legacy;
        _next = next;
    }

    public async Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
    {
        var ids = productIds.ToList();
        var legacyResult = await _legacy.GetByIdsAsync(ids);
        var nextResult = await _next.GetByIdsAsync(ids);

        // 差分があればログに出す（正はまだ旧系）
        CompareAndLog(legacyResult, nextResult);

        return legacyResult;
    }

    private static void CompareAndLog(
        IReadOnlyList<Product> legacy, IReadOnlyList<Product> next) { /* ... */ }
}
