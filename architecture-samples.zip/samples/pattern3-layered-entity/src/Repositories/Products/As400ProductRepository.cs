using Sample.Models.Products;

namespace Sample.Repositories.Products;

/// <summary>AS400側の実装。移行中は両方が存在する。</summary>
public class As400ProductRepository : IProductRepository
{
    public Task<IReadOnlyList<Product>> GetByIdsAsync(IEnumerable<string> productIds)
        => throw new NotImplementedException();
}
